# NLIM_set_fianl 最终设计与比赛提交包

本项目最终设计方案及统一交付名称为 **`NLIM_set_fianl`**，于 **2026-11-03** 确认。包内包含配套运行文件、完整工程、设计报告、九张软硬件框图、性能证据和 Skill。固件内部版本为 `NLIM_set_fianl`，固件、启动镜像、接收程序与报告采用统一交付标识。

系统以 EES331（XC7Z020CLG484-1）为平台，PL 负责连续采样与 CNN 运算，PS 负责事件提取、KNN/拒识/登记匹配、计量和规则，电脑网页负责显示、操作和保存日志。新电器学习是参考库增量登记，不更新神经网络权重。

## 先看哪些文件

| 内容 | 位置 |
|---|---|
| 设计报告 | `report/design_report.md`、`report/design_report.html` |
| 九张最终软硬件框图 | `report/diagrams/`：PNG、SVG、PDF 与预览页 |
| 最终方案确认与版本对应 | `report/final_design.md` |
| 配套运行包 | `board/release/` |
| 完整 PS、HLS、RTL、IP、约束及网页源代码 | `src/` |
| 复现与构建 | `build/README.md` |
| 本地测试脚本和本次重跑结果 | `sim/tests/`、`sim/results/` |
| 理论性能及原始报告 | `evidence/performance/` |
| 已有实现和数值证据 | `evidence/` |
| 黄金参考数据和历史现场故障日志 | `data/` |
| 可复用 Skill | `skill/README.md` |
| 大模型协作记录 | `report/ai_collaboration.md` |

## 运行方式

1. 开发板断电，备份 SD 卡。将 `board/release/sd_card/BOOT.BIN` 复制到 SD 根目录；保留卡内登记文件 `NILM430.BIN`、`NILM431.BIN`。
2. 重新上电，电脑与板卡通过网线连接。板卡默认地址为 `192.168.1.10`；电脑有线网卡应处于相同网段且地址不冲突。
3. 运行 `board/release/check_connection.cmd`，再运行 `board/release/start_capture.cmd`。接收工具不要求安装 Vitis 或 Python。
4. 自检显示 `NLIM_set_fianl` 是本包的正确版本。网页显示电器、事件、计量、规则和登记管理。采集日志在运行工具旁的 `recordings/` 中生成。

## 验证材料

已收集的证据包括 HLS/RTL 协同仿真、既有布局布线报告、模型数值比对和本地回归；本次也在新目录执行复现检查。具体完成项以 `evidence/reproduction/` 及 `sim/results/` 为准。

用户已确认本包为最终设计方案。四路卷积核心的四倍理论吞吐以同频、同精度、II=1 的单通路结构为基线；CNN 延迟分别采用 HLS 综合估计和 RTL 协同仿真数据。

## 完整性校验

安装 Python 3 后，在包根目录运行：

```powershell
python skill/ps-pl-release-validation/scripts/verify_delivery.py .
```

校验只读文件，不连接板卡。`checksums.json` 用于检查传输损坏，不替代功能验证。`submission_manifest.json` 记录最终交付名称、真实固件版本、设计确认日期和验证边界。

## 目录与版权

包内保留第三方文件原有版权声明，工程源码、模型资产、构建材料及图纸按目录分类归档。

工程目录与源文件沿用原命名，图纸采用章节编号及中文名称；README.md、SKILL.md、CMakeLists.txt、BOOT.BIN 等工具约定名称保留大小写。生成的 `work/`、开发工具缓存及测试可执行文件不属于最终源码交付。报告正文为中文，可打印 HTML 用于阅读和导出。
